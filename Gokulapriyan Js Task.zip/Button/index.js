let name1 = document.querySelector("#btn1")


function showalert1(){
    name1.classList.toggle("show1")
}


name1.addEventListener("click",showalert1)

let name2 = document.querySelector("#btn2")


function showalert2(){
    name2.classList.toggle("show2")
}


name2.addEventListener("click",showalert2)

let name3 = document.querySelector("#btn3")


function showalert3(){
    name3.classList.toggle("show3")
}


name3.addEventListener("click",showalert3)