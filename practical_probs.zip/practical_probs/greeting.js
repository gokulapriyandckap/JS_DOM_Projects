// Write a function which takes input string and outputs the concatenated string
// ("govind")=> hello govind
// ("richard")=> hello richard

function greeting(name){
    return "hello"+ "*" +name
}

console.log(greeting("bush"))