const btn = document.querySelectorAll('button')
const para = document.querySelectorAll('.question-text')
 

for(let i= 0; i < btn.length; i++){
    btn[i].addEventListener('click',function(){
        for(let j = 0;j< para.length ;j++){
            if(btn[i].classList.contains('first')){
                para[0].classList.toggle('show')
                para[1].classList.remove('show')
                para[2].classList.remove('show')
            }
            else if(btn[i].classList.contains('second')){
                para[0].classList.remove('show')
                para[1].classList.toggle('show')
                para[2].classList.remove('show')
            }
            else if(btn[i].classList.contains('third')){
                para[0].classList.remove('show')
                para[1].classList.remove('show')
                para[2].classList.toggle('show')
            }

        }
    })
    
}