const Questions = [{
     id : 0,
    ques: "1. Which is the longest river in the world?",
    ans: [{ text1: "nile", isCorrect: true },
        { text2: "ganga", isCorrect: false },
        { text3: "Amazon", isCorrect: false },
        { text4: "cauvery", isCorrect: false }
    ]
},
{
    id: 1,
    ques: "2. Which is india's first super computer?",
    ans: [{ text1: "Para80000", isCorrect: false,},
        { text2: "para800", isCorrect: false },
        { text3: "param80000", isCorrect: false },
        { text4: "Param8000", isCorrect: true }
    ]
},
{
   id : 2,
    ques: "3. What is the capital of Gujarat",
    ans: [{ text1: "surat", isCorrect: false },
        { text2: "vadodara", isCorrect: false },
        { text3: "gandhinagar", isCorrect: true },
        { text4: "rajkot", isCorrect: false }
    ]
},
{
    id : 3,
     ques: "4. Who is the Accounting Manger Of Dckap Explorers",
     ans: [{ text1: "Yuvaraj", isCorrect: false },
         { text2: "Amrish", isCorrect: false },
         { text3: "Vignesh Shankar", isCorrect: true },
         { text4: "Kishore kumar", isCorrect: false }
     ]
 }
]

const qtns = document.getElementById("questions");
const right= document.querySelector("#true");
const wrong= document.querySelector("#false");
const opt1 = document.querySelector("#opt-1");
const opt2 = document.querySelector("#opt-2");
const opt3 = document.querySelector("#opt-3");
const opt4 = document.querySelector("#opt-4");
const nxtbtn = document.querySelector("#nxt-btn");
const options = document.querySelectorAll(".opt");

window.addEventListener("DOMContentLoaded",()=>{
    qtns.innerText = Questions[0].ques
    opt1.innerText = Questions[0].ans[0].text1
    opt2.innerText = Questions[0].ans[1].text2
    opt3.innerText = Questions[0].ans[2].text3
    opt4.innerText = Questions[0].ans[3].text4 
    // if (Questions[0].ans[0].isCorrect === true   ) {
    //     ans.innerText ="True";
    //     ans.style.color = "green";
    //    }
})

let i = 0
nxtbtn.addEventListener("click",(e)=>{
    i++
    if (i ==4 ) {
        i=1
    }
    qtns.innerText = Questions[i].ques
    opt1.innerText = Questions[i].ans[0].text1
    opt2.innerText = Questions[i].ans[1].text2
    opt3.innerText = Questions[i].ans[2].text3
    opt4.innerText = Questions[i].ans[3].text4  
    right.classList.remove("show")

    for (let j = 0; j < options.length; j++) {
        options[j].addEventListener("click",(e)=>{
           if (Questions[i].ans[j].isCorrect === true   ) {
            right.classList.add("show")
            right.style.color="green"
            // setTimeout(() => {
            //     right.classList.remove("show")
            // },1500);
           }
           else{
            wrong.classList.add("show")
            wrong.style.color="red "
            right.classList.remove("show")
            setTimeout(() => {
                wrong.classList.remove("show")
            },1000);
           }
        })   
    }
})



